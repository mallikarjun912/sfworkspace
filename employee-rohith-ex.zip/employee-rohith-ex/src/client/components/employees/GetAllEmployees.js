import React, { useEffect } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { Navigate } from "react-router-dom";
import EmployeeAction from "../../../redux/action/EmployeeAction";
import { useSelector } from "react-redux/es/exports";
import UserAction from "../../../redux/action/UserAction";
const GetAllEmployees = () => {
  let navigate = useNavigate();
  let location = useLocation();
  let params = useParams();
  const employeeAction = EmployeeAction();
  const userAction = UserAction();
  const { employees, user } = useSelector((state) => {
    const shallowCopy = { ...state };
    return {
      employees: shallowCopy.employees || [],
      user: shallowCopy.user || null,
    };
  });
  let isAdmin = (user && user.role && user.role === "admin") || false;

  useEffect(() => {
    if (employees.length === 0) {
      employeeAction.getEmployees();
    }
  }, []);

  const AdminButtons = ({ id }) => {
    return (
      <React.Fragment>
        <td>
          <Link to={`/employee/${id}`}>
            <button className="btn btn-warning">Update</button>
          </Link>
        </td>
        <td>
          <div
            onClick={() => {
              employeeAction.deleteEmployee(id);
            }}
          >
            <button className="btn btn-danger">Delete</button>
          </div>
        </td>
      </React.Fragment>
    );
  };

  const prepareDate = (dateStr) => {
    const date = new Date(dateStr);
    return [date.getDate(), date.getMonth() + 1, date.getFullYear()].join("/");
  };
  return user ? (
    <div>
      {isAdmin && (
        <React.Fragment>
          <Link to={"/employee/new"}>
            <button className="large ui button primary">Add Employee</button>
          </Link>
        </React.Fragment>
      )}
      <table className="table table-striped" align="center" width="50%" border="0">
        <caption>
          <h1 align="center">Employee Information</h1>
        </caption>
        <thead>
          <tr align="center">
            <th>EMPL CODE</th>
            <th>EMPL NAME</th>
            <th>JOB</th>
            <th>SALARY</th>
            <th>DATE JOINED</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.empcode}>
              <td>{emp.empcode}</td>
              <td>{emp.empname}</td>
              <td>{emp.job}</td>
              <td>{emp.salary}</td>
              <td>{prepareDate(emp.doj)}</td>
              {isAdmin && <AdminButtons id={emp.empcode} />}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <Navigate to="/login" />
  );
};
export default GetAllEmployees;
