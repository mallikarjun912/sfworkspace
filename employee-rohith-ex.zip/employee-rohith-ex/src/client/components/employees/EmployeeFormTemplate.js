import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { REQUEST_TYPE, serverRequest } from "../../../axios";
import EmployeeAction from "../../../redux/action/EmployeeAction";
import { useNavigate } from "react-router-dom";

const EmployeeFormTemplate = () => {
  const { id } = useParams();
  const employeeAction = EmployeeAction();
  const [employee, setEmployee] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    if (id) {
      getEmployeeById();
    }
  }, []);

  const getEmployeeById = async () => {
    try {
      const response = await serverRequest(REQUEST_TYPE.GET, `/employee/${id}`);
      if (response.status === 200) {
        setEmployee({ ...response.data, doj: formatDate(response.data.doj) });
      }
    } catch (err) {
      console.log(err);
    }
  };

  function padTo2Digits(num) {
    return num.toString().padStart(2, "0");
  }

  function formatDate(dateStr) {
    const date = new Date(dateStr);
    return [date.getFullYear(), padTo2Digits(date.getMonth() + 1), padTo2Digits(date.getDate())].join("-");
  }

  const onInputChange = (event) => {
    setEmployee({ ...employee, [event.target.name]: event.target.value });
  };

  const onSubmit = (event) => {
    event.preventDefault();
    if (id) {
      employeeAction.editEmployee(employee, navigate);
    } else {
      employeeAction.addEmployee(employee, navigate);
    }
  };
  return (
    <div className="align-items-center container">
      <h1 className="text-center">{id ? "Update Employee" : "Add New Employee"}</h1>
      <form>
        <div className="form-group justify-content-center">
          <label>Enter Employee code</label>
          <input
            type={"text"}
            name="empcode"
            className="form-control"
            value={employee.empcode || ""}
            onChange={onInputChange}
          ></input>
          <label>Enter Employee name</label>
          <input
            type={"text"}
            name="empname"
            className="form-control"
            value={employee.empname || ""}
            onChange={onInputChange}
          ></input>
          <label>Enter Employee Job</label>
          <input
            type={"text"}
            name="job"
            className="form-control"
            value={employee.job || ""}
            onChange={onInputChange}
          ></input>
          <label>Enter Employee salary</label>
          <input
            type={"text"}
            name="salary"
            className="form-control"
            value={employee.salary || ""}
            onChange={onInputChange}
          ></input>
          <label>Enter Joining Date</label>
          <input
            type={"date"}
            name="doj"
            className="form-control"
            value={employee.doj || ""}
            onChange={onInputChange}
          ></input>
        </div>
        <button className="ui button medium green" onClick={onSubmit}>
          {id ? "Update Employee" : "Add Employee"}
        </button>
        &nbsp;&nbsp;
        <Link to={"/"}>
          <button className="ui primary button medium">Cancel</button>{" "}
        </Link>
      </form>
    </div>
  );
};
export default EmployeeFormTemplate;
