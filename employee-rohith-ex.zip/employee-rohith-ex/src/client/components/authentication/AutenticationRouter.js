import { Link } from "react-router-dom";
import { useSelector } from "react-redux/es/exports";
import React from "react";
import { Outlet } from "react-router-dom";
const AuthenticationRouter = (props) => {
  const user = useSelector((state) => state.user);
  if (!user) {
    return (
      <React.Fragment>
        <h2>
          you are not authenticated!...<Link to="/login">click here</Link> to go to Login Page{" "}
        </h2>
      </React.Fragment>
    );
  }
  if (props.isAdminRoute && user && user.role === "user") {
    return (
      <React.Fragment>
        <h2>
          Only Admin Can access this route.Pls Login With Admin Credentials <Link to="/login">click here</Link> to go to
          Login Page{" "}
        </h2>
      </React.Fragment>
    );
  }

  return <Outlet />;
};
export default AuthenticationRouter;
