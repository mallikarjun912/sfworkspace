import React, { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { useSelector } from "react-redux/es/exports";

import UserAction from "../../../redux/action/UserAction";
const Login = () => {
  const [userDetails, setUserDetails] = useState({ username: "", password: "" });
  const userAction = UserAction();
  const user = useSelector((state) => state.user);
  const onInputChange = (event) => {
    setUserDetails({ ...userDetails, [event.target.name]: event.target.value });
  };

  const onSubmit = (event) => {
    event.preventDefault();
    userAction.login(userDetails);
  };
  return user ? (
    <Navigate to="/" />
  ) : (
    <React.Fragment>
      <div className="text-center container align-items-center container">
        <h1>Login Page</h1>
        <form className="ui form">
          <div className="form-group">
            <label>Username</label>
            <input
              type="text"
              name="username"
              className="form-control"
              value={userDetails.username}
              onChange={onInputChange}
              required
            ></input>
            <br></br>
            <label>Password</label>
            <input
              type="text"
              name="password"
              className="form-control"
              value={userDetails.password}
              onChange={onInputChange}
              required
            ></input>
            <br></br>
          </div>
          <button className="btn btn-success" onClick={onSubmit}>
            Login
          </button>
          &emsp;&emsp;
          <Link to="/">
            <button
              className="btn btn-info"
              onClick={() => {
                alert("create new account then");
              }}
            >
              Forgot password
            </button>
          </Link>
        </form>
      </div>
    </React.Fragment>
  );
};
export default Login;
