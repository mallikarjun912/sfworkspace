import { LOGOUT } from "./UserReducer";

export const GET_EMPLOYEES = "GET_EMPLOYEES";
export const ADD_EMPLOYEE = "ADD_EMPLOYEE";
export const DELETE_EMPLOYEE = "DELETE_EMPLOYEE";
export const EDIT_EMPLOYEE = "EDIT_EMPLOYEE";
export const GET_EMPLOYEE_BY_ID = "GET_EMPLOYEE_BY_ID";

const EmployeeReducer = (state = [], action) => {
  let employees = [...state];
  switch (action.type) {
    case GET_EMPLOYEES:
      return [...action.payload];
    case ADD_EMPLOYEE: {
      employees.push(action.payload);
      return employees;
    }
    case EDIT_EMPLOYEE: {
      const index = employees.findIndex((employee) => employee.empcode === action.payload.empcode);
      employees[index] = { ...employees[index], ...action.payload };
      return employees;
    }
    case DELETE_EMPLOYEE: {
      employees = employees.filter((employee) => employee.empcode !== action.payload);
      return employees;
    }
    case GET_EMPLOYEE_BY_ID: {
      const employee = employees.filter((employee) => employee.id === action.payload);
      return employee;
    }
    case LOGOUT: {
      return [];
    }
    default:
      return state;
  }
};
export default EmployeeReducer;
