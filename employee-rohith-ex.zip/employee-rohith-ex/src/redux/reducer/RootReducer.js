import { combineReducers } from "redux";
import EmployeeReducer from "./EmployeeReducer";
import UserReducer from "./UserReducer";

const RootReducer = combineReducers({
  employees: EmployeeReducer,
  user: UserReducer,
});
export default RootReducer;
