import { useDispatch } from "react-redux";
import { REQUEST_TYPE, serverRequest } from "../../axios";
import { ADD_EMPLOYEE, DELETE_EMPLOYEE, EDIT_EMPLOYEE, GET_EMPLOYEES } from "../reducer/EmployeeReducer";

function EmployeeAction() {
  const dispatch = useDispatch();

  const getEmployees = async () => {
    try {
      const response = await serverRequest(REQUEST_TYPE.GET, "/employee");
      if (response.status === 200) {
        dispatch({ type: GET_EMPLOYEES, payload: response.data });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const addEmployee = async (employee, navigate) => {
    try {
      const response = await serverRequest(REQUEST_TYPE.POST, `/employee`, employee);
      if (response.status === 200) {
        navigate("/");
        alert(response.data);
        return dispatch({ type: ADD_EMPLOYEE, payload: employee });
      }
    } catch (err) {
      console.log(err);
    }
  };
  const deleteEmployee = async (id) => {
    try {
      const response = await serverRequest(REQUEST_TYPE.DELETE, `/employee/${id}`);
      if (response.status === 200) {
        alert(response.data);
        return dispatch({ type: DELETE_EMPLOYEE, payload: id });
      }
    } catch (err) {
      console.log(err);
    }
  };
  const editEmployee = async (employee, navigate) => {
    try {
      const response = await serverRequest(REQUEST_TYPE.PUT, `/employee`, employee);
      if (response.status === 200) {
        navigate("/");
        alert(response.data);
        return dispatch({ type: EDIT_EMPLOYEE, payload: employee });
      }
    } catch (err) {
      console.log(err);
    }
  };

  const getEmployeeById = async (id) => {
    try {
      const response = await serverRequest(REQUEST_TYPE.GET, `/employee/${id}`);
      if (response.status === 200) {
        return response;
      }
    } catch (err) {
      console.log(err);
    }
  };
  return Object.freeze({ addEmployee, getEmployees, editEmployee, deleteEmployee, getEmployeeById });
}

export default EmployeeAction;
