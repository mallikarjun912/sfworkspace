import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AuthenticationRouter from "./client/components/authentication/AutenticationRouter";
import Login from "./client/components/authentication/Login";
import EmployeeFormTemplate from "./client/components/employees/EmployeeFormTemplate";
import GetAllEmployees from "./client/components/employees/GetAllEmployees";
import Header from "./client/components/essential/Header";
import { persistor, store } from "./redux/store";
import { PersistGate } from "redux-persist/integration/react";
import FallBack from "./client/components/essential/FallBack";

const Routing = () => {
  return (
    <Provider store={store}>
      <PersistGate loading={<h1>Loading....</h1>} persistor={persistor}>
        <BrowserRouter>
          <Header />
          <Routes>
            <Route element={<AuthenticationRouter isAdminRoute={true} />}>
              <Route path="/employee/new" element={<EmployeeFormTemplate />} />
              <Route path="/employee/:id" element={<EmployeeFormTemplate />} />
            </Route>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<GetAllEmployees />} />

            <Route path="*" exact element={<FallBack />} />
          </Routes>
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
};

export default Routing;
